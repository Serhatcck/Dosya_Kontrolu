package dosya;

public abstract class Dosya {
	public String SeriNo;
	public String Desi;
	public String Tur;
	public String Icerik;
	
	public String Plaka;
	public String MaxDesi;
	public String OzelDesi;
	public String SigortaDesi;
}
