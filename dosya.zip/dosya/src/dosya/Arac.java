package dosya;

public class Arac extends Dosya{
	public Arac(String plaka, String ozelDesi, String maxDesi, String sigortaDesi) {
		this.Plaka = plaka;
		this.MaxDesi = maxDesi;
		this.OzelDesi = ozelDesi;
		this.SigortaDesi = sigortaDesi;
	}
}
